package com.example.james.gmaps;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.IOException;

public class MainActivity extends AppCompatActivity implements OnClickListener{
    TextView highScore;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        int hs = sp.getInt("highScore", 999999);
        if (hs != 999999) {
            highScore = (TextView) findViewById(R.id.highScoreIntro);
            highScore.setText("Lowest Score: " + hs + " miles");
        }
        Button startButton = (Button) findViewById(R.id.startButton);
        startButton.setOnClickListener(this);

        Button setName = (Button) findViewById(R.id.setName);
        setName.setOnClickListener(this);
        ImageView shopButton = (ImageView) findViewById(R.id.shopButton);
        shopButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.startButton) {
            Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
            intent.putExtra("roundNum", 0);
            intent.putExtra("totScore", 0);
            startActivity(intent);
        }


        else if (v.getId() == R.id.setName) {
            Intent intent = new Intent(getApplicationContext(), SetName.class);
            startActivity(intent);
        }
        else if (v.getId() == R.id.shopButton) {
            Intent intent = new Intent(getApplicationContext(), shop.class);
            startActivity(intent);
        }
    }

}
