package com.example.james.gmaps;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.content.SharedPreferences;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class SetName extends Activity implements OnClickListener {

    SharedPreferences sp;
    EditText enterName;
    int coins;
    int highScore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_name);
        enterName = (EditText) findViewById(R.id.enterName);
        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String name = sp.getString("username", "Guest");
        coins = sp.getInt("coins", 0);
        highScore = sp.getInt("highScore", 999999);
        enterName.setText(name);
        enterName.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                boolean handled = false;
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    SharedPreferences.Editor editor = sp.edit();
                    editor.clear();
                    editor.putString("username", enterName.getText().toString());
                    editor.putInt("coins", coins);
                    editor.putInt("highScore", highScore);
                    editor.commit();
                    handled = true;
               }
                return handled;
            }
        });
        ImageView backButton = (ImageView) findViewById(R.id.backButton);
        backButton.setOnClickListener(this);
        Button submitName = (Button) findViewById(R.id.submitName);
        submitName.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.backButton) {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        }
        else if (v.getId() == R.id.submitName) {
            SharedPreferences.Editor editor = sp.edit();
            editor.clear();
            editor.putString("username", enterName.getText().toString());
            editor.putInt("coins", coins);
            editor.putInt("highScore", highScore);
            editor.commit();
        }

    }
}
