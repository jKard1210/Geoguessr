package com.example.james.gmaps;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.multidex.MultiDex;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.StreetViewPanoramaLocation;
import com.google.android.gms.maps.model.StreetViewPanoramaLink;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.OnStreetViewPanoramaReadyCallback;
import com.google.android.gms.maps.StreetViewPanorama;
import com.google.android.gms.maps.SupportStreetViewPanoramaFragment;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, OnClickListener {

    private GoogleMap mMap;

    public LatLng location1;
    private StreetViewPanorama pano1;
    int totalDistance;
    int roundNum;
    double lat;
    double longitude;

    private LatLng SYDNEY;

    public SupportStreetViewPanoramaFragment streetViewPanoramaFragment;
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        int iten = getIntent().getExtras().getInt("int", 0);
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String file1 = sp.getString("citiesLat", "citiesLat.txt");
        String file2 = sp.getString("citiesLong", "citiesLong.txt");
        ArrayList longitudes = new ArrayList();
        ArrayList latitudes = new ArrayList();

        try {

            BufferedReader input = new BufferedReader(new InputStreamReader(getAssets().open(file1)));
            double line;
            if (!input.ready()) {
                throw new IOException();
            }
            for (int i = 0; i < 100; i++) {
                line = Double.parseDouble(input.readLine());
                latitudes.add(line);
            }
            input.close();
        }
        catch (IOException e) {
            System.out.println(e);
        }

        try {

            BufferedReader input2 = new BufferedReader(new InputStreamReader(getAssets().open(file2)));
            double line2;
            if (!input2.ready()) {
                throw new IOException();
            }
            for (int j = 0; j < 100; j++) {
                line2 = Double.parseDouble(input2.readLine());
                longitudes.add(line2);
            }
            input2.close();
        }
        catch (IOException e) {
            System.out.println(e);
        }



        if (iten == 0) {

            int randNum = (int)(Math.random() * 100.0);
            lat = Double.parseDouble(latitudes.get(randNum).toString());
            longitude = Double.parseDouble(longitudes.get(randNum).toString());
        }
        else {
            lat = getIntent().getExtras().getDouble("lat", 0);
        longitude = getIntent().getExtras().getDouble("longitude", 0);
        }
        SYDNEY = new LatLng(lat, longitude);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        streetViewPanoramaFragment =
                (SupportStreetViewPanoramaFragment)
                        getSupportFragmentManager().findFragmentById(R.id.streetviewpanorama);
        streetViewPanoramaFragment.getStreetViewPanoramaAsync(
                new OnStreetViewPanoramaReadyCallback() {
                    @Override
                    public void onStreetViewPanoramaReady(StreetViewPanorama p) {
                        // Only set the panorama to SYDNEY on startup (when no panoramas have been
                        // loaded which is when the savedInstanceState is null).
                        if (savedInstanceState == null) {
                            p.setPosition(SYDNEY, 2000000);
                            p.setStreetNamesEnabled(false);
                        }

                    }
                });

        ImageView markerButton = (ImageView) findViewById(R.id.marker);
        totalDistance = getIntent().getExtras().getInt("totScore");
        roundNum = getIntent().getExtras().getInt("roundNum");
        markerButton.setOnClickListener(this);
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(newBase);
        MultiDex.install(this);
    }
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera

        mMap.addMarker(new MarkerOptions().position(SYDNEY).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(SYDNEY));

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.marker) {
            location1 = streetViewPanoramaFragment.getStreetViewPanorama().getLocation().position;
            openMap();
        }
    }

    public void openMap() {
        double latitude2 = location1.latitude;
        double longitude2 = location1.longitude;
        Intent intent = new Intent(getApplicationContext(), MapGuess.class);
        intent.putExtra("lat", latitude2);
        intent.putExtra("longitude", longitude2);
        intent.putExtra("roundNum", roundNum);
        intent.putExtra("totScore", totalDistance);
        double guessLat = intent.getExtras().getDouble("guessLat");
        double guessLongitude = intent.getExtras().getDouble("guessLongitude");
        intent.putExtra("guessLat", guessLat);
        intent.putExtra("guessLongitude", guessLongitude);
        startActivity(intent);
    }
}
