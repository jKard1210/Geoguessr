package com.example.james.gmaps;

import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;


import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;


import java.util.ArrayList;
import java.util.List;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;


import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.message.BasicNameValuePair;

public class LeaderboardActivity extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.leaderboard);
        send();
    }

    public void send()
    {
        // get the message from the message text box
        String url = "http://geoguess1.netai.net/androidmessages.html";
        String url1 = "http://geoguess1.netai.net/usernames.html";
        String html = "";
        String html1 = "";
        // make sure the fields are not empty
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);
        HttpClient client = new DefaultHttpClient();

        HttpGet request = new HttpGet(url);

        try {
            HttpResponse response = client.execute(request);
            InputStream in = response.getEntity().getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            StringBuilder str = new StringBuilder();
            String line = null;
            for (int i = 0; i < 10; i++) {
                    line = reader.readLine();
                    str.append(line + " ");
                    str.append("\n");
            }
            in.close();
            html = str.toString();

            HttpClient client1 = new DefaultHttpClient();
            HttpGet request1 = new HttpGet(url1);
            HttpResponse response1 = client1.execute(request1);
            InputStream in1 = response1.getEntity().getContent();
            BufferedReader reader1 = new BufferedReader(new InputStreamReader(in1));
            StringBuilder str1 = new StringBuilder();
            String line1 = null;
            for (int j = 0; j < 10; j++) {
                        line1 = reader1.readLine();
                        str1.append(line1 + " ");
                        str1.append("\n");


            }
            in1.close();
            html1 = str1.toString();
        }
        catch (ClientProtocolException e) {
            // TODO Auto-generated catch block
            System.out.println("no");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            System.out.println("yes");
        }


        TextView leaderboardText = (TextView) findViewById(R.id.usersText);
        leaderboardText.setText(html);
        TextView scoreText = (TextView) findViewById(R.id.scoresText);
        scoreText.setText(html1);
        }


    }


