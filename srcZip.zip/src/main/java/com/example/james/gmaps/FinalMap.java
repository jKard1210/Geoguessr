package com.example.james.gmaps;

import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.apache.http.client.ClientProtocolException;


import java.util.ArrayList;
import java.util.List;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;


import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.message.BasicNameValuePair;
import java.io.IOException;
import android.os.StrictMode;

public class FinalMap extends FragmentActivity implements OnMapReadyCallback, View.OnClickListener {

    private GoogleMap mMap;
    double latitude;
    double longitude;
    double guessLat;
    double guessLong;
    int roundNum;
    String name;
    int totalDistance;
    boolean finalRound = false;
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_map);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        latitude = getIntent().getExtras().getDouble("lat");
        longitude = getIntent().getExtras().getDouble("longitude");
        guessLat = getIntent().getExtras().getDouble("guessLat");
        guessLong = getIntent().getExtras().getDouble("guessLong");
        roundNum = getIntent().getExtras().getInt("roundNum");
        roundNum += 1;
        totalDistance = getIntent().getExtras().getInt("totScore");

        float[] results = new float[3];
        Location.distanceBetween(latitude, longitude, guessLat, guessLong, results);
        int distance = (int) results[0];
        totalDistance += (distance/1609);
        TextView finScore = (TextView) findViewById(R.id.finScoreText);
        if(distance < 1609) {
            int finalDistance = distance;
            finScore.setText("" + finalDistance + " meters");
        }
        else {
            int finalDistance = distance / 1609;
            finScore.setText("" + finalDistance + " miles");
        }
        TextView roundNumText = (TextView) findViewById(R.id.roundNum);
        roundNumText.setText("Round " + roundNum + "/5");
        TextView totDistance = (TextView) findViewById(R.id.totalScore);
        totDistance.setText("Total distance: " + totalDistance + " miles");
        if(roundNum == 5) {
           lastRound();
        }
        ImageView forwardButton = (ImageView) findViewById(R.id.finalForward);
        forwardButton.setOnClickListener(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng realLoc = new LatLng(latitude, longitude);
        LatLng guess = new LatLng(guessLat, guessLong);
        mMap.addMarker(new MarkerOptions().position(realLoc).title("True Location"));
        mMap.addMarker(new MarkerOptions().position(guess).title("Guess Location"));
    }

    @Override
    public void onClick(View v) {
        if(finalRound) {
            endGame(totalDistance);
        }
        else {
            Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
            intent.putExtra("roundNum", roundNum);
            intent.putExtra("totScore", totalDistance);
            intent.putExtra("int", 0);
            startActivity(intent);
        }
    }
    public void lastRound() {
        finalRound = true;
        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        name = sp.getString("username", "guest");
        SharedPreferences.Editor editor = sp.edit();
        int coins = sp.getInt("coins", 0);
        if(totalDistance < sp.getInt("highScore", 999999))
        {
            editor.clear();
            editor.putInt("highScore", totalDistance);
            editor.putInt("coins", coins);
            editor.putString("username", name);
            editor.commit();
        }
        int highScore = sp.getInt("highScore", 0);
        editor.clear();
        int coinsNew = coins + (100000/totalDistance);
        editor.putInt("coins", coinsNew);
        editor.putInt("highScore", highScore);
        editor.putString("username", name);
        editor.commit();
        TextView coinsText = (TextView) findViewById(R.id.Coins);
        coinsText.setText("Coins: " + coins);
        TextView gainedCoins = (TextView) findViewById(R.id.gainedCoins);
        gainedCoins.setText("+ " + (coinsNew - coins));
        TextView highScoreText = (TextView) findViewById(R.id.highScoreText);
        highScoreText.setText("Lowest Score: " + highScore + " miles");

        sendScore(totalDistance, name);
    }

    public void sendScore(int score, String user) {


        HttpClient httpclient = new DefaultHttpClient();
        HttpPost httppost = new HttpPost("http://geoguess1.netai.net/leaderboard.php");
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        try {
            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
            nameValuePairs.add(new BasicNameValuePair("name", user));
            nameValuePairs.add(new BasicNameValuePair("message", score + ""));
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            StrictMode.setThreadPolicy(policy);
            httpclient.execute(httppost);
            // clear text box
        } catch (ClientProtocolException e) {
            // TODO Auto-generated catch block
            System.out.println("no");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            System.out.println("yes");
        }

    }
    public void endGame(int fin) {

        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);

    }
}
