package com.example.james.gmaps;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.app.Activity;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


/**
 * Created by James on 9/25/2016.
 */
public class shop extends Activity implements View.OnClickListener {
    int coins;
    boolean canAfford;
    SharedPreferences sp;
    TextView americaCost;
    TextView europeCost;
    TextView canAffordText;
    Button useAmerica;
    Button useEurope;
    Button useDefault;
    String name;
    int highScore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shop);
        sp =  PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        coins = sp.getInt("coins", 0);
        canAfford = true;
        TextView coinsText = (TextView) findViewById(R.id.shopCoins);
        coinsText.setText(coins + " coins");
        americaCost = (TextView) findViewById(R.id.americaCost);
        americaCost.setOnClickListener(this);
        europeCost = (TextView) findViewById(R.id.europeCost);
        europeCost.setOnClickListener(this);
        useAmerica = (Button) findViewById(R.id.useAmerica);
        useEurope = (Button) findViewById(R.id.useEurope);
        useDefault = (Button) findViewById(R.id.useDefault);
        boolean americaBought = sp.getBoolean("americaBought", false);
        boolean europeBought = sp.getBoolean("europeBought", false);
        canAffordText = (TextView) findViewById(R.id.canAffordText);
        highScore = sp.getInt("highScore", 1000000);
        name = sp.getString("username", "guest");


        if (coins < 500)
        {
            americaCost.setTextColor(Color.RED);
            europeCost.setTextColor(Color.RED);
            canAfford = false;
        }
        else {
            americaCost.setTextColor(Color.GREEN);
            europeCost.setTextColor(Color.GREEN);
        }
        if (americaBought) {
            americaCost.setText("");
            americaCost.setTextColor(Color.GREEN);
            useAmerica.setWidth(250);
            useAmerica.setText("Use");
            useAmerica.setOnClickListener(this);
        }
        if (europeBought) {
            europeCost.setText("");
            europeCost.setTextColor(Color.GREEN);
            useEurope.setWidth(250);
            useEurope.setText("Use");
            useEurope.setOnClickListener(this);
        }
        useDefault.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.americaCost) {
            if (canAfford) {
                coins = coins - 500;
                if (coins < 500) {
                    canAfford = false;
                }
                SharedPreferences.Editor editor = sp.edit();
                editor.putInt("coins", coins);
                editor.putBoolean("americaBought", true);
                editor.apply();
                americaCost.setText("");
                useAmerica.setText("Use");
                useAmerica.setOnClickListener(this);

            }
            else {
                canAffordText.setText("You can not afford this item");
            }

        }
        else if (v.getId() == R.id.europeCost) {
            if (canAfford) {
                coins = coins - 500;
                if (coins < 500)
                {
                    canAfford = false;
                }
                SharedPreferences.Editor editor = sp.edit();
                editor.putInt("coins", coins);
                editor.putBoolean("europeBought", true);
                editor.apply();
                europeCost.setText("");
                useEurope.setText("Use");
                useEurope.setOnClickListener(this);

            }
            else {
                canAffordText.setText("You can not afford this item");
                canAffordText.setTextColor(Color.RED);
            }

        }

        else if (v.getId() == R.id.useAmerica) {
                sp =  PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("citiesLat", "americaLat.txt");
                editor.putString("citiesLong", "americaLong.txt");
                editor.apply();
                canAffordText.setText("American locations will be used");
                canAffordText.setTextColor(Color.GREEN);
        }
        else if (v.getId() == R.id.useEurope) {
            sp =  PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("citiesLat", "europeLat.txt");
            editor.putString("citiesLong", "europeLong.txt");
            editor.apply();
            canAffordText.setText("European locations will be used");
            canAffordText.setTextColor(Color.GREEN);
        }
        else if (v.getId() == R.id.useDefault) {
            sp =  PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            SharedPreferences.Editor editor = sp.edit();
            editor.clear();
            editor.putString("username", name);
            editor.putInt("highScore", highScore);
            editor.putInt("coins", coins);
            editor.putString("citiesLat", "citiesLat.txt");
            editor.putString("citiesLong", "citiesLong.txt");
            editor.commit();
            canAffordText.setText("Default locations will be used");
            canAffordText.setTextColor(Color.GREEN);
        }



    }
}
