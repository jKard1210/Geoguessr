package com.example.james.gmaps;

import android.location.Location;
import android.support.v4.app.FragmentActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.io.IOException;

public class MapGuess extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMapClickListener, View.OnClickListener {

    public GoogleMap mMap;
    double lat;
    LatLng guessPoint;
    double guessLat;
    double longitude;
    ImageView advanceButton;
    ImageView backButton;
    double guessLongitude;
    public GoogleMap mMap1;
    int roundNum;
    int totalDistance;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_guess);
        lat = getIntent().getExtras().getDouble("lat");
        longitude = getIntent().getExtras().getDouble("longitude");
        totalDistance = getIntent().getExtras().getInt("totScore");
        roundNum = getIntent().getExtras().getInt("roundNum");
        guessLongitude = getIntent().getExtras().getDouble("guessLongitude", 0);
        guessLat = getIntent().getExtras().getDouble("guessLat", 0);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap){
            mMap = googleMap;
            backButton = (ImageView) findViewById(R.id.backArrow);
            backButton.setOnClickListener(this);
            mMap.setOnMapClickListener(this);
            LatLng startMarkerPos = new LatLng(guessLat, guessLongitude);
            mMap.addMarker(new MarkerOptions().position(startMarkerPos).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
    }

    @Override
    public void onMapClick(LatLng point) {
        guessPoint = point;
        mMap.addMarker(new MarkerOptions().position(guessPoint).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
        guessLat = point.latitude;
        guessLongitude = point.longitude;
        advanceButton = (ImageView) findViewById(R.id.forwardArrow);
        advanceButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.forwardArrow) {
            Intent intent = new Intent(getApplicationContext(), FinalMap.class);
            intent.putExtra("lat", lat);
            intent.putExtra("longitude", longitude);
            intent.putExtra("guessLat", guessLat);
            intent.putExtra("guessLong", guessLongitude);
            intent.putExtra("roundNum", roundNum);
            intent.putExtra("totScore", totalDistance);
            startActivity(intent);
        }
        else if (v.getId() == R.id.backArrow) {
            Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
            intent.putExtra("lat", lat);
            intent.putExtra("longitude", longitude);
            intent.putExtra("guessLat", guessLat);
            intent.putExtra("guessLongitude", guessLongitude);
            intent.putExtra("int", 1);
            startActivity(intent);
        }
    }


}
